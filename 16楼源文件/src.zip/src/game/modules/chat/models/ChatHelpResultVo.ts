/**
* 聊天求助发送结果
*/
module game.modules.chat.models{
	export class ChatHelpResultVo{
		public result:number;  					 // 0 成功
		constructor(){

		}
	}
}