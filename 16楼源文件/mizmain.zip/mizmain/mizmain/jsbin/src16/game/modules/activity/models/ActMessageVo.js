/**
* 活动推送信息
*/
var game;
(function (game) {
    var modules;
    (function (modules) {
        var activity;
        (function (activity) {
            var models;
            (function (models) {
                var ActMessageVo = /** @class */ (function () {
                    function ActMessageVo() {
                    }
                    return ActMessageVo;
                }());
                models.ActMessageVo = ActMessageVo;
            })(models = activity.models || (activity.models = {}));
        })(activity = modules.activity || (modules.activity = {}));
    })(modules = game.modules || (game.modules = {}));
})(game || (game = {}));
//# sourceMappingURL=ActMessageVo.js.map