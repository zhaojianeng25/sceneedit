/*
* name;
*/
var game;
(function (game) {
    var data;
    (function (data) {
        var Teleport = /** @class */ (function () {
            function Teleport() {
            }
            return Teleport;
        }());
        data.Teleport = Teleport;
    })(data = game.data || (game.data = {}));
})(game || (game = {}));
//# sourceMappingURL=Teleport.js.map