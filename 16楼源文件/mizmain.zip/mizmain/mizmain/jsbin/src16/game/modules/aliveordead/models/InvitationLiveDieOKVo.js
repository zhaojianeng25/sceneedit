var game;
(function (game) {
    var modules;
    (function (modules) {
        var aliveordead;
        (function (aliveordead) {
            var models;
            (function (models) {
                /** 战仙会（生死斗）被下战书返回的信息 */
                var InvitationLiveDieOKVo = /** @class */ (function () {
                    function InvitationLiveDieOKVo() {
                    }
                    return InvitationLiveDieOKVo;
                }());
                models.InvitationLiveDieOKVo = InvitationLiveDieOKVo;
            })(models = aliveordead.models || (aliveordead.models = {}));
        })(aliveordead = modules.aliveordead || (modules.aliveordead = {}));
    })(modules = game.modules || (game.modules = {}));
})(game || (game = {}));
//# sourceMappingURL=InvitationLiveDieOKVo.js.map