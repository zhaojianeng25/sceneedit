/**
* name
*/
var game;
(function (game) {
    var data;
    (function (data) {
        var MapFarData = /** @class */ (function () {
            function MapFarData() {
                this.xMoveRate = 0;
                this.yMoveRate = 0;
            }
            return MapFarData;
        }());
        data.MapFarData = MapFarData;
    })(data = game.data || (game.data = {}));
})(game || (game = {}));
//# sourceMappingURL=MapFarData.js.map