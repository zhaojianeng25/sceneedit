/**
*
*/
var game;
(function (game) {
    var modules;
    (function (modules) {
        var chat;
        (function (chat) {
            var models;
            (function (models) {
                var ChatItemTips = /** @class */ (function () {
                    function ChatItemTips() {
                    }
                    return ChatItemTips;
                }());
                models.ChatItemTips = ChatItemTips;
            })(models = chat.models || (chat.models = {}));
        })(chat = modules.chat || (modules.chat = {}));
    })(modules = game.modules || (game.modules = {}));
})(game || (game = {}));
//# sourceMappingURL=ChatItemTips.js.map