
module game.modules.bag.models{
	/**
	 * @describe  评分；key的类型是ScoreTypes
	 */
	export class RoleScoreVo {
		/**服务器返回的评分 */
		public score: Laya.Dictionary;
		//获取、设置属性
		constructor(){

		}
	}
}