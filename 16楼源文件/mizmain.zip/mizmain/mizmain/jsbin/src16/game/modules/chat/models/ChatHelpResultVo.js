/**
* 聊天求助发送结果
*/
var game;
(function (game) {
    var modules;
    (function (modules) {
        var chat;
        (function (chat) {
            var models;
            (function (models) {
                var ChatHelpResultVo = /** @class */ (function () {
                    function ChatHelpResultVo() {
                    }
                    return ChatHelpResultVo;
                }());
                models.ChatHelpResultVo = ChatHelpResultVo;
            })(models = chat.models || (chat.models = {}));
        })(chat = modules.chat || (modules.chat = {}));
    })(modules = game.modules || (game.modules = {}));
})(game || (game = {}));
//# sourceMappingURL=ChatHelpResultVo.js.map