/**
* 
*/
module game.modules.chat.models{
	export class ChatItemTips{
		public displayinfo:DisplayInfoVo;  					 // 
		public tips:any; 					 				// 
		constructor(){

		}
	}
}