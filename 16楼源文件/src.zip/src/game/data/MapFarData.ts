/**
* name 
*/
module game.data{
	export class MapFarData{
		name:string;
		depth:number;
		x:number;
		y:number;
		width:number;
		height:number;
		xMoveRate:number = 0;
		yMoveRate:number = 0;
	}
}