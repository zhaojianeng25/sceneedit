var game;
(function (game) {
    var modules;
    (function (modules) {
        var aliveordead;
        (function (aliveordead) {
            var models;
            (function (models) {
                /** 战仙会（生死斗）下战书返回的信息 */
                var InvitationSuccessVo = /** @class */ (function () {
                    function InvitationSuccessVo() {
                    }
                    return InvitationSuccessVo;
                }());
                models.InvitationSuccessVo = InvitationSuccessVo;
            })(models = aliveordead.models || (aliveordead.models = {}));
        })(aliveordead = modules.aliveordead || (modules.aliveordead = {}));
    })(modules = game.modules || (game.modules = {}));
})(game || (game = {}));
//# sourceMappingURL=InvitationSuccessVo.js.map