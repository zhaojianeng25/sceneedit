/**
* name
*/
var game;
(function (game) {
    var data;
    (function (data) {
        var Circle = /** @class */ (function () {
            function Circle(_x, _y, _radius) {
                this.x = _x;
                this.y = _y;
                this.radius = _radius;
            }
            return Circle;
        }());
        data.Circle = Circle;
    })(data = game.data || (game.data = {}));
})(game || (game = {}));
//# sourceMappingURL=Circle.js.map